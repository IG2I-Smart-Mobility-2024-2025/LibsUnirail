# README

## Lib xBee
Utilisation des xbee en mode API.
Librairie par les Communications GSM-R

