# README

## Lib CAN

Contient les messages et les fonctions utilent pour la plateforme unirail
elle contient les identifiants et les champs de chaque trame CAN.

Il y a aussi les fonctions CAN pour le RaspberryPi
