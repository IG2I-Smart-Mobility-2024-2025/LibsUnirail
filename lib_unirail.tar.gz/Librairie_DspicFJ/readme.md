# README

Dossier de la librairie

### Librairie pour DSPICFJ
Contient les librairies pour le DSPICFJ
- Clock : Permet d'initialiser la PLL du Microcontroleur
- ECAN1_DSPICFJ :  Configuration du CAN et réception et envoi
- ECAN1_Addon : parametrage du CAN
- Lib_I2C : Configuartion de l'I2C et utilisation
- MCP342X : pour utiliser les convertisseurs Analogique-numérique
- Utilitaires : conversion ascii-hexa