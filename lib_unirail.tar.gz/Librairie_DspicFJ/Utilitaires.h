#ifndef UTILITAIRES_H
#define	UTILITAIRES_H


unsigned char ascii_to_hexa(unsigned char x);
unsigned char hexa_to_ascii(unsigned char x);
//uint8_t two_bytes_ascii_to_hexa(uint8_t a,uint8_t b)
unsigned char two_bytes_ascii_to_hexa(unsigned char a,unsigned char b);
#endif	/* UTILITAIRES_H */