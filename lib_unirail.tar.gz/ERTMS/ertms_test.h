#ifndef ERTMS_TEST_H
	#define	ERTMS_TEST_H

	#include <stdlib.h>
	#include <check.h>
	#include "ertms.h"

	#include "ertms_init_tests.c"
	#include "ertms_serialize_tests.c"

	
#endif
	
